package com.zensar.services;

import com.zensar.entity.Product;

public interface ProductService {

	Product insertProduct(Product product);  

}
